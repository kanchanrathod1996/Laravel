<!DOCTYPE html>
<html>
<head>
    <title>Insert Multiple Selected Checkbox Values To Database In Laravel 9 - Techsolutionstuff</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha256-aAr2Zpq8MZ+YA/D6JtRD3xtrwpEz2IqOS+pWD/7XKIw=" crossorigin="anonymous" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha256-OFRAJNoaD8L3Br5lglV7VyLRf0itmoBzWUoM+Sji4/8=" crossorigin="anonymous"></script>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header bg-info">
                        <h6 class="text-white">Insert Multiple Selected Checkbox Values To Database In Laravel 9 - Techsolutionstuff</h6>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-12 ">
                                <a href="{{ URL::to ('student.create') }}" class="btn btn-success"> New Create</a>
                            </div>
                        </div>
                        <table class="table table-bordered">
                            <tr>
                                <th>Title</th>
                                <th>Name</th>
                                <th>Bod</th>
                                <th>Age</th>
                                <th>Gender</th>
                                <th>Phone</th>
                                <th>Address</th>
                                <th>Email</th>

                                <th>Category</th>
                                <th>action</th>

                            </tr>
                            @foreach($students as $item)
                            <tr>
                                <td>{{ $item->title }}</td>
                                <td>{{ $item->name }}</td>
                                <td>{{ $item->bday }}</td>
                                <td>{{ $item->age }}</td>
                                <td>{{ $item->gender }}</td>
                                <td>{{ $item->phone }}</td>
                                <td>{{ $item->address }}</td>
                                <td>{{ $item->email }}</td>
                                <td>
                                    {{-- @foreach($student->category as $value)


                                        {{$value}},
                                  @endforeach --}}
                                    {{-- @foreach(explode(',', $student->category) as $value)
                                   {{$value}}
                                  @endforeach --}}

                                @foreach($item->category as  $categories)


                                     {{($categories)}}

                                 @endforeach

                                </td>
                                <td>
                                     {{-- <form method="POST" action="{{ route('/student' . '/' . $item->id) }}" accept-charset="UTF-8" style="display:inline">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-danger btn-sm" title="Delete group" onclick="return confirm(&quot;Confirm delete?&quot;)"><i class="fa fa-trash-o" aria-hidden="true"></i> Delete</button> --}}

                                        <a class="btn btn-primary" href="{{ route('student.edit',$item->id) }}">Edit</a>
                                        <a class="btn btn-info" href="{{ route('student.show',$item->id) }}">Show</a>
                                        @csrf
                                        @method('DELETE')
                                        <a  class="btn btn-danger btn-sm" href="{{ route('student.destroy',$item->id) }}">delete</a>
                                    {{-- </form> --}}
                                </td>
                            </tr>
                            @endforeach
                        </table>
                        {{-- <div class="d-flex justify-content-center ">
                            {{ $students->links('vendor.pagination.custom')}}
                        </div> --}}
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
